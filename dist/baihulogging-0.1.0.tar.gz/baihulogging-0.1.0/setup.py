from setuptools import setup, find_packages

setup(
    name="BaihuLogging",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    author="Baihu",
    description="A logging bot which can log messages to Discord",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/baihufox3210/Baihu-Logging",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)